/**
 * Created by ww on 2016/12/2.
 */
var commom_url="http://api.yindianmall.com";


var classic=(function () {
        //点击左侧栏切换对应右侧页面
    function leftBar() {
        window.onload = function () {
            var lis = $('.goodsclassify li');
           lis.eq(0).addClass('selected');
           var defaultId=lis.eq(0).attr('cat_id');
           getClickEvent(defaultId);
            for (var i = 0; i < lis.length; i++) {
                lis[i].index = i;
                $(lis[i]).tap(function () {
                    //点击左侧时颜色改变
                    $(this).addClass('selected').siblings().removeClass('selected');
                    var carId=$(this).attr('cat_id');
                    getClickEvent(carId)
                });
            }
        };
    }
    function searchFunc() {
        //点击分类页搜索部分网页跳转search
        var $search = $('.search');
        $search.tap(function () {
            window.location.href = '../search.html'
        });
    }
    //点击相应的分类商品，通过它的id值跳转到相应的分类详情页面
    function clickClass() {
             var  $lastList=$('.lastList');
             console.log($lastList);
        $lastList.tap(function () {
            var id=$(this).attr('parentId');
            var curId=$(this).attr('catId');
            window.location.href='./classDetail.html?id='+id+'&brandId='+curId;
        })
    }
    /*ajax功能代码的实现*/
    function getClickEvent(carId) {
        $.ajax({
                  //  url: 'http://139.224.3.9:10888/b2b2c/api/v2/mobile/goodscat/list/app/catId.do',
                    url: ""+commom_url+"/api/v2/mobile/goodscat/list/app/catId.do",
                   // url: 'http://www.yindianmall.com/api/v2/mobile/goodscat/list/app/catId.do',
                    dataType: 'jsonp',
                    data: {
                        catId: carId
                    },
                    success: function (data) {
                        $('.goodsall').html('');
                        console.log(data);
                        var str = '';
                        str += "<div class='all selectThings0' style='display:block;'>";
                        for (var i = 0; i < data.data.length; i++) {
                            for (var m = 0; m < data.data[i].children.length; m++) {
                                str += "<div class='selectHead'>";
                                str += "<div class='candy'>" + data.data[i].children[m].name + "</div>";
                                str += "</div>";
                                str += "<div class='selectLast'>";
                                for (var j = 0; j < data.data[i].children[m].children.length; j++) {
                                    str += "<div class='lastList' catId="+data.data[i].children[m].children[j].cat_id+" parentId='"+data.data[i].children[m].cat_id+"' >";
                                    str += "<div class='sailList'><img src=" + data.data[i].children[m].children[j].image + "></div>";
                                    str += "<a href='javascript:;'>" + data.data[i].children[m].children[j].name + "</a>";
                                    str += "</div>";
                                }

                            }

                            str += "</div>";
                            str += "</div>";
                        }
                        $('.goodsall').html(str);
                        clickClass();


                    }
                });
    }
    //获取第一个主类别的商品分类列表
    function getList() {
        //获取第一个主类别的商品分类列表
        $.ajax({
         //   url: "http://192.168.1.100:28080/b2b2c/api/v2/mobile/goodscat/list/app/first.do",
          //  url:'http://139.224.3.9:10888/b2b2c/api/v2/mobile/goodscat/list/app/first.do',
            url:""+commom_url+"/api/v2/mobile/goodscat/list/app/first.do",
            dataType: 'jsonp',
            success: function (data) {
                console.log(data);
                var str = '';
                for (var i = 0; i < data.data.length; i++) {
                    str += "<li class='allClassify' cat_id=" + data.data[i].cat_id + ">" + data.data[i].name + "</li>";
                }
                $('.goodsclassify').html(str);
            }
        });
    }
    return{
        init:function(){
            leftBar();
            searchFunc();
            getList();
          }
    }
})();

classic.init();
















