var commom_url="http://api.yindianmall.com";

setTimeout(
    function () {
        var maxHeight = $('.show_content').get(0).offsetHeight - $('.main').get(0).offsetHeight;
        var pageNo = 1;
        console.log(maxHeight);
        //卷曲高度scrollTop
        $('.show_content').get(0).addEventListener('swipeUp', function () {
            var scrollHeight = $('section').get(0).scrollTop;
            console.log(scrollHeight);
            //高度改变需要重新计算
            maxHeight = $('.show_content').get(0).offsetHeight - $('.main').get(0).offsetHeight;
            scrollHeight = $('section').get(0).scrollTop;
            if ((scrollHeight - maxHeight) < 5) {
                pageNo++;
                $.ajax({
                    //url: "http://www.yindianmall.com/api/v2/mobile/showcase/getSelectGoods.do",
                    // url: "http://139.224.3.9:10888/b2b2c/api/v2/mobile/showcase/getSelectGoods.do",
                    url: ""+commom_url+"/api/v2/mobile/showcase/getSelectGoods.do",
                    dataType: "jsonp",
                    data: {
                        id:window.location.href.queryURLParameter()["id"] ,
                        pageNo: pageNo
                    },
                    success: function (data) {
                        console.log(data);
                        console.log(pageNo);
                        if (data.result === 1) {
                            var contentList = document.getElementById('contentList');
                            var str = '';
                            for (var i = 0; i < data.data.goodsList.length; i++) {
                                var cur = data.data.goodsList[i];
                                str += "<li goodId=" + cur.goods_id + "><div>";
                                str += "<img src=" + cur.small + "></div>";
                                str += "<p class='specific'>" + cur.name + "</p>";
                                str += "<p class='price'>￥" + cur.price + "</p><i class='icon'>销量:" + cur.buyNum + "</i>";
                                str += "</li>";
                            }
                            $('.show_content').append(str)
                        }
                    }
                })


            }
        });

    },
    3000
);






