/**
 * Created by ww on 2017/1/16.
 */

var module=(function () {
    var $return=$('.return');
    var $time=$('.time');

    /*抢购时段左右滑动效果*/
  function swipe() {
        //上面时间段的左右滑动(等字符串拼完所以设定定时)
        var list = document.getElementsByClassName('time')[0];
        var lis = list.getElementsByTagName('li');
        list.style.width = lis.length * lis[0].offsetWidth + 'px';
        var maxX = list.offsetWidth - document.body.offsetWidth;
        var startX;
        var _x;
        list.addEventListener('touchstart', function (e) {
            startX = e.changedTouches[0].pageX;
            _x = css(this, 'translateX');
        }, false);
        list.addEventListener('touchmove', function (e) {
            var moveX = e.changedTouches[0].pageX;
            var disX = moveX - startX + _x;
            if (Math.abs(css(this, 'translateX')) > maxX) {
                return
            }
            if (css(this, 'translateX') > 0) {
                return
            }
            css(this, 'translateX', disX);
        }, false);
        list.addEventListener('touchend', function (e) {
            startX = e.changedTouches[0].pageX;
            if (Math.abs(css(list, 'translateX')) > maxX) {
                css(list, 'translateX', -maxX)
            }
            if (css(this, 'translateX') > 0) {
                css(list, 'translateX', 0)
            }
        }, false);

        //点击上面时间段添加样式
        $('.time li').tap(function () {

        });


    };
//进度条样式的改变
    function progress() {
        //进度条样式的改变
        $('.line_one').css("width", "" + parseFloat($(".percent").html()) * 4.5 / 100 + "rem");
    }

//当商品卖到100%时候对应样式改变
    function is_saleout() {
        ($('.percent').html() == '100%') ? ($('.goods_li_r_content_footer_r').html('<span>抢完啦</span>').css('background-color', '#888888')) : ($('.goods_li_r_content_footer_r').html('<span>马上抢></span>'));
    }
//抢购活动-列表查询
    function purChaseCheck() {
        $.ajax({
           // url: 'http://139.224.3.9:10888/b2b2c/api/v2/mobile/limitbuy/limitbuyActiveList.do',
            url: 'http://139.224.3.9:9090/api/v2/mobile/limitbuy/limitbuyActiveList.do',
            dataType: 'jsonp',
            success: function (data) {
                   console.log(data);
                var str = '';
                for (var i = 0; i < data.data.length; i++) {
                    str += "<li act_id=" + data.data[i].act_id + " end="+data.data[i].end_time_stamp+" startTime="+data.data[i].start_time+">";
                    str += "<p class='time_point'>" + data.data[i].start_time + "</p>";
                    str += "<p class='sale_status'>" + data.data[i].act_status_str + "</p>";
                    str += "</li>"
                }
                $('.time').html(str);
                brandList();
            }
        });
        defaultEvent();

    }
    //  点击列表首页各项，使其有选中样式的同时发送ajax请求，绑定对应的列表商品
    function brandList() {
        var $timeLi=$time.children('li');
        for(var i=0;i<$timeLi.length;i++){
            var cur=$timeLi[i];
            var curTime=new Date(),
                spanTime=curTime.getTime();
            if (spanTime<=cur.getAttribute('end')) {
                var itemId = $(cur).attr('act_id');
                $(cur).addClass('select_time').siblings().removeClass('select_time');
                ajaxInvite.call(cur,itemId);
                break;
            }
        }

      /*  $timeLi.forEach(function (item,index) {

        });*/
        $timeLi.tap(function () {
            $(this).addClass('select_time').siblings().removeClass('select_time');
            $(this).siblings().forEach(function (item,index) {
                if($(item)[0].timer){
                    window.clearInterval($(item)[0].timer);
                }
            });
            var actId = $(this).attr('act_id');
            ajaxInvite.call(this,actId)
        })
    }
    // 抢购活动-商品列表查询
    function ajaxInvite(actId) {
        var _this=this;
        $.ajax({
           // url: 'http://139.224.3.9:10888/b2b2c/api/v2/mobile/limitbuy/limitbuyGoodsList.do',
            url: 'http://139.224.3.9:9090/api/v2/mobile/limitbuy/limitbuyGoodsList.do',
            data: {
                act_id: actId
            },
            dataType: 'jsonp',
            success: function (data) {
                console.log(data);

                var str = '';
                for (var i = 0,cur=data.data.result.length; i <cur ; i++) {
                    var curD=data.data.result[i];
                    str += "<li actID='"+curD.act_id+"' goodID='"+curD.goods_id+"'>";
                    str += "<div class='goods_li_l'>";
                    str += "<img src=" + data.data.result[i].wap_thumbnail_src + ">";
                    str += "</div>";
                    str += "<div class='goods_li_r'>";
                    str += "<div class='goods_li_r_content'>";
                    str += "<p class='goods_li_r_introduce'>";
                    str += data.data.result[i].goods_name;
                    str += "</p>";
                    str += "<div class='goods_li_r_content_mid'>";
                    str += "<span>已抢购</span>";
                    str += "<span class='percent'>" + Math.floor((data.data.result[i].buy_num / data.data.result[i].goods_num) * 10000) / 100 + "% </span>";
                    str += "<div class='line'>";
                    str += "<span class='line_one'></span>";
                    str += "</div>";
                    str += "<span class='alreadySale'>已抢购" + data.data.result[i].buy_num + "件</span>";
                    str += "</div>";
                    str += "<div class='goods_li_r_content_footer'>";
                    str += "<div class='goods_li_r_content_footer_l'>";
                    str += "<span class='price_now'>¥" + data.data.result[i].price + "</span>";
                    str += " <del class='price_ori'>¥" + data.data.result[i].original_price + "</del>";
                    str += "</div>";
                    str += "<div class='goods_li_r_content_footer_r rightAway'>";
                    str += "<span >" + data.data.result[i].lb_status_str + "></span>";
                    str += "</div>";
                    str += "</div>";
                    str += "</div>";
                    str += "</div>";
                    str += "</li>";
                }
                $('.goods').html(str);
                /*调用左右滑动的函数*/
                swipe();
                /*调用外层函数*/
                //is_saleout();
                progress();
                countDown.call(_this);
                changeColor(data);

            }
        });
        defaultEvent();
    }
//抢购活动-商品开抢提醒
    function purchaseRemind() {
        $.ajax({
          //  url: 'http://139.224.3.9:10888/b2b2c/api/v2/mobile/limitbuy/remindMe.do',
            url: 'http://139.224.3.9:9090/api/v2/mobile/limitbuy/remindMe.do',
            data: {
                member_id: 1,
                lb_id: 1
            },
            async: false,
            dataType: 'jsonp',
            success: function (data) {
            }
        });
        defaultEvent();
    }
    //抢购倒计时
    function countDown() {
        var startT=$(this).attr('startTime').slice(0,2);
        var _this=this;
        function formateTime() {
            window.clearTimeout(_this.timer);
            var $endTip=$('.endTip');
            var tarTime=$(_this).attr('end');
            var $ter=$('.terminal_time_r');
            var $tipEnd=$('.tipEnd');
            var str='';
            var curtime=new Date(),
                curSpan=curtime.getTime();
            var y=curtime.getFullYear(),
                m=curtime.getMonth(),
                d=curtime.getDate();
            var startShop=new Date(y,m,d,startT,00,00).getTime();
            if(startShop>=curSpan){
                countStart(startShop,curSpan,str,$ter,$tipEnd,$endTip);
            }
            else{
                var  tarSpan=tarTime,
                    differTime=tarSpan-curSpan,
                    h = Math.floor(differTime / (1000 * 60 * 60)),
                    spanH = differTime - h * (1000 * 60 * 60),
                    min = Math.floor(spanH / (1000 * 60)),
                    spanMin = spanH - min * (1000 * 60),
                    sec = Math.floor(spanMin / 1000);
                if(differTime<=0){
                    $ter.css('display','none');
                    $tipEnd.css('display','block');
                    $tipEnd[0].innerHTML='抢购活动已结束！';
                    window.clearTimeout(_this.timer);
                    return;
                }else {
                    if(str===''&&differTime>=0){
                        $endTip.html('距离本场结束:');
                        str += '<span class="terminal_time_limit">' + zero(h) + '</span>';
                        str += '<span>:</span><span class="terminal_time_limit">' + zero(min) + '</span>';
                        str += '<span>:</span><span class="terminal_time_limit">' + zero(sec) + '</span>';
                        $ter.css('display', 'block');
                        $tipEnd.css('display', 'none');
                        $ter[0].innerHTML = str;
                    }
                }
            }
       _this.timer=window.setTimeout(formateTime,1000);
        }
        formateTime();
    }
    /*距离本场开始倒计时*/
    function countStart(startShop,curSpan,str,$ter,$tipEnd,$endTip) {
        $endTip.html('距离本场开始:');
        var tarSpan=startShop;
        var differTime=tarSpan-curSpan;
        var h = Math.floor(differTime / (1000 * 60 * 60)),
            spanH = differTime - h * (1000 * 60 * 60);
        var min = Math.floor(spanH / (1000 * 60)),
            spanMin = spanH - min * (1000 * 60);
        var sec = Math.floor(spanMin / 1000);
        str += '<span class="terminal_time_limit">' + zero(h) + '</span>';
        str += '<span>:</span><span class="terminal_time_limit">' + zero(min) + '</span>';
        str += '<span>:</span><span class="terminal_time_limit">' + zero(sec) + '</span>';
        $ter.css('display', 'block');
        $tipEnd.css('display', 'none');
        $ter[0].innerHTML = str;
    }
    /*当数字小于10的时候，在他的前面自动添加上一个零*/
    function zero(val){
            return val<10?'0'+val:val;
        }
    
    /*当对应区域的内容为提醒我的时候，让他对应的样式由红色改为绿色*/
    function changeColor() {
        clickShop();
        var $right=$('.rightAway'),
            $span=$right.children('span');
        var str=$span.html(), subStr='马上抢',subStrTwo='提醒我';
        if(str.indexOf(subStr)>=0){
            return;
        }else{
            if(str.indexOf(subStrTwo)>=0){
                $span.html('提醒我');
                $right.css('background','green');
            }else{
                $span.html('已结束');
                $right.css('background','gray');
            }
        }
        remindPart($span);
    }
    //点击返回按钮，返回首页
    function backIndex() {
       $return.tap(function () {
           window.location.href='./index.html'
       })
    }
    
    // 提醒功能操作
    function remindPart($span) {
        $span.tap(function () {
            console.log($(this).html());
            if($(this).html()==='提醒我'){
             $(this).html('取消提醒');
            $(this).parent().css('background','grey');
           // alert('提醒成功');
         }else {
                if($(this).html()==='取消提醒'){
                    $(this).html('提醒我');
                    $(this).parent().css('background', 'green');
                }else {
                    return;
                }
            // confirm('确定要取消提醒吗?')
         }
        }
        )
    }


    //点击马上抢，执行相应的操作
    function clickShop() {
        var $right=$('.rightAway'),
            $span=$right.children('span');
        $span.tap(function () {
            if($(this)[0].innerText==='马上抢>'){
                var $Li=$(this).parents('li');

         var actId=$Li.attr('actid'),
             goodId=$Li.attr('goodid');
         console.log(actId,goodId);
                turnToBrandList(actId,goodId);
            }

        })
    }

    //马上抢-跳转至商品详情页（已完成-暂时不用）
    function turnToBrandList(actId,goodId) {

        window.location.href='./brand/brandList.html?id='+goodId+'&act='+actId+'';
    }
    //禁止默认事件


    function defaultEvent() {
        var $main=$('.main');
            $document=$(document);
        $main.on('touchmove', function (e) {
            e.stopPropagation(); }, false);
        $document.on('touchmove', function (e) {
            e.preventDefault(); }, false);
    }
    return {
        init:function () {
            purChaseCheck();
            purchaseRemind();
            backIndex();
            defaultEvent();
        }
    }
})();
module.init();
















