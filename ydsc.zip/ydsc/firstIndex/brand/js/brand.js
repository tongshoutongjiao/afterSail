/**
 * Created by ww on 2016/12/2.
 */
var commom_url="http://api.yindianmall.com";

//轮播
var mySwiper = new Swiper('.swiper-container', {
    loop: true,
    // 如果需要分页器
    pagination: '.swiper-pagination',
    // 如果需要前进后退按钮
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    observer:true
    // 如果需要滚动条
    // scrollbar: '.swiper-scrollbar',
});
// document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);
/*window.setTimeout(function () {
    var $picWrapper = $('.picWrapper');
    $picWrapper.css('height', document.documentElement.clientHeight-$('.header')[0].clientHeight-$('.detailMsg')[0].clientHeight-$('.lastIndex')[0].offsetHeight);

    var myScroll = new IScroll('.picWrapper',{
        vScrollbar:false
    });
    var $partOne = $('.partOne');
    $partOne.css('height', document.documentElement.clientHeight-$('header')[0].clientHeight-$('footer')[0].offsetHeight);
    var myScrollTwo = new IScroll('.partOne',{
        vScrollbar:false
    });
},3000);*/
var brand = (function () {
    var $body=$('body');
    //点击三个圆点出现小弹框.................................................
    function clickDot() {
        var flag = true;
        $('.more').tap(function () {
            //console.log(111);
            if (flag == true) {
                $('.brandList').css('display', 'block');
                return flag = false;
            } else {
                // console.log(222)
                $('.brandList').css("display", "none");
                flag = true;
            }
        });
    }

    //使详情页的基本信息和商品属性和商家承诺部分固定在基本信息页面的头部；
    function tie() {
        var $picWrapper = $('.picWrapper'),
            $detailMsg=$('.detailMsg'),
            $header=$('.header'),
            $lastIndex=$('.lastIndex');
        $picWrapper.css('height', document.documentElement.clientHeight - $header[0].offsetHeight - $detailMsg[0].clientHeight-$lastIndex[0].clientHeight);
        var myScroll = new IScroll('.picWrapper');
    }



    //点击商品详情评价使点击项有选中样式..........................................
    function switchItem() {
        var lis = $('.goods li');
        for (var i = 0; i < lis.length; i++) {
            //console.log(lis[i])
            lis[i].index = i;
            $(lis[i]).tap(function () {
                    $(this).addClass('selected').siblings().removeClass('selected');
                    $('section').css('display', 'none');
                    $('section').get(this.index).style.display = 'block';

            })

        }
    }

    //点击购物车出现选择页面小动画,点击提交按钮关闭.........................................
    function cartFuc() {
     /*   $('.myCart').tap(function () {
            setTimeout(function () {
                $('.selectcolsize').css('display', 'block')
                    .css('transition', 'all 2s')
                    .css('transform', 'translateY(-5rem)')
            }, 500);
        });*/
        $('section').tap(function () {
            setTimeout(function () {
                $('.selectcolsize').css('display', 'none')
                    .css('transition', 'all 1s')
                    .css('transform', 'translateY(5rem)')
            }, 500);
        });

        $('submit').tap(function () {
            setTimeout(function () {
                $('.selectcolsize').css('display', 'none')
                    .css('transition', 'all 1s')
                    .css('transform', 'translateY(5rem)')
            }, 500);
        });
    }

    //点击详情页对应下面的图
    function brandLis() {
        $('.basenews').tap(function () {
            $('.pic .one').css('display', 'block').siblings().css('display', 'none')
        });
        $('.goodsnature').tap(function () {
            $('.pic .two').css('display', 'block').siblings().css('display', 'none')
        });
        $('.promise').tap(function () {
            $('.pic .thr').css('display', 'block').siblings().css('display', 'none')
        });
    }

    //评价页对应页面。。。。。。。。。。。。。。。。。。。。。。
    function comment(goodsId) {
        var $discuss=$('.discuss');
        $Li=$discuss.children('li')[0];
        var obj={};
        obj={
            goodsId:goodsId,
            type:1,
            pageNo:'1',
            pageSize:'10'
        };
        getComment(obj);
        $discuss.children('li').tap(function () {
            var index = $(this).index();
            var obj={};
            if(index===0){
                //记录被点击的索引
                $(this).addClass('select').siblings().removeClass('select');
                obj={
                    goodsId:goodsId,
                    type:1,
                    pageNo:'1',
                    pageSize:'10'
                };
                getComment(obj);
            }else if(index===1){
                $(this).addClass('select').siblings().removeClass('select');
                obj={
                    goodsId:goodsId,
                    type:1,
                    grade:'5',
                    pageNo:1,
                    pageSize:10
                };
                getComment(obj);

            }else if(index===2){
                $(this).addClass('select').siblings().removeClass('select');
                obj={
                    goodsId:goodsId,
                    type:1,
                    grade:'2',
                    pageNo:1,
                    pageSize:10
                };
                getComment(obj);
            }else{
                $(this).addClass('select').siblings().removeClass('select');
                obj={
                    goodsId:goodsId,
                    type:1,
                    grade:'1',
                    pageNo:'1',
                    pageSize:'10'
                };
                getComment(obj);
            }
            // 遍历中评差评等对应的页面
           /* for (var i = 0; i < $('.arr').length; i++) {
                //   console.log( $('.arr').eq(index));
                $('.arr').eq(index).css('display', 'block').siblings().css('display', 'none')

            }*/
        });
    }
    //点击查看全部评价按钮，跳转到评价页面.
    function clickCheckComment() {
        var $checkAllComment=$('.checkAllComment');
        var lis = $('.goods li');
        var index=lis.length-1;
        $checkAllComment.tap(function () {
                        $(lis[index]).addClass('selected').siblings().removeClass('selected');
                        $('section').css('display', 'none');
                        $('section').get(index).style.display = 'block'
                    })
    }
    /*发送ajax请求部分*/

    /*按照一定的规则从url地址中把相应的参数值获取到*/
    String.prototype.queryURLParameter=function(){
        var obj={},
            reg=/([^?=&#]+)=([^?=&#]+)/g;
        this.replace(reg,function(){
            var key=arguments[1],
                value=arguments[2];
            obj[key]=value;
        });
        return obj;
    };

    /*从url地址中获取到某个产品的id值，并将其传递给相应的函数*/
    function defaultMsg(){
        var Id=window.location.href.queryURLParameter()["id"];
        var catId=window.location.href.queryURLParameter()["act"];
        if(typeof Id==="undefined"){
            $body[0].style.display='none';
            alert('请返回上级页面选择商品');
            return;
        }
        if(catId&&typeof catId!=='undefined'){

            //抢购部分倒计时
            setMessage(Id,catId);
            //获取商品规格，默认，选取每一个规格的第一个值
            getRegular(Id);
            //获取商品规格，通过点击页面动态获取
            getPage(Id);
            // //获取商品(详情-基本信息)
            getBasic(Id);
            //获取商品(详情-商品属性)
            getBrandAttr(Id);
            //商品评价的初步获取，总数，好评率
            commentRate(Id);
            //    获取评价页面的具体信息
            comment(Id);
        }
        //获取商品规格，默认，选取每一个规格的第一个值
        getRegular(Id);
        //获取商品规格，通过点击页面动态获取
        getPage(Id);
        // //获取商品(详情-基本信息)
        getBasic(Id);
        //获取商品(详情-商品属性)
        getBrandAttr(Id);
        //商品评价的初步获取，总数，好评率
        commentRate(Id);
    //    获取评价页面的具体信息
        comment(Id);
    }

    //抢购部分倒计时
    function setMessage(Id,catId) {
        var $countDown=$('#countDown');
        $.ajax({
          //  url:'http://139.224.3.9:10888/b2b2c/api/v2/mobile/limitbuy/immediatelySnatch.do',
            url:""+commom_url+"/api/v2/mobile/limitbuy/immediatelySnatch.do",
            dataType:'jsonp',
            data:{
                act_id:catId,
                goods_id:Id
            },
            success:function (data) {
                console.log(data);
                var $countDown=$('#countDown');
                countDown($countDown,data);

            }
        });
        defaultEvent();
    }

    //设置抢购商品的倒计时
    function countDown($countDown,data) {
        var tarTime=data.data.limitbuyAct.end_time;
        function formateTime() {
            console.log(tarTime);
            var str='',
                curtime=new Date(),
                curSpan=curtime.getTime(),
                tarSpan=tarTime*1000,
                differTime=tarSpan-curSpan;
                h= Math.floor(differTime / (1000 * 60 * 60)),
                    spanH = differTime - h * (1000 * 60 * 60),
                    min = Math.floor(spanH / (1000 * 60)),
                    spanMin = spanH - min * (1000 * 60),
                    sec = Math.floor(spanMin / 1000);
                if(differTime<=0){
                   $countDown.css('display','block').html('抢购活动已结束');
                    window.clearTimeout(timer);
                    return;
                }else {
                    if(str===''&&differTime>=0){
                         str+='限时抢购时间还有:'+zero(h)+':'+zero(min)+':'+zero(sec);
                    }
                    $countDown.css('display','block').html(str);
                }
              var  timer=window.setTimeout(formateTime,1000)
        }
        function zero(n) {
            return n<10?('0'+n):n
        }
        formateTime();
    }


    function countDown1() {
        var startT=$(this).attr('startTime').slice(0,2);
        var _this=this;
        function formateTime() {
            window.clearTimeout(_this.timer);
            var $endTip=$('.endTip');
            var tarTime=$(_this).attr('end');
            var $ter=$('.terminal_time_r');
            var $tipEnd=$('.tipEnd');
            var str='';
            var curtime=new Date(),
                curSpan=curtime.getTime();
            var y=curtime.getFullYear(),
                m=curtime.getMonth(),
                d=curtime.getDate();
            var startShop=new Date(y,m,d,startT,00,00).getTime();
            if(startShop>=curSpan){
                countStart(startShop,curSpan,str,$ter,$tipEnd,$endTip);
            }
            else{
                var  tarSpan=tarTime,
                    differTime=tarSpan-curSpan,
                    h = Math.floor(differTime / (1000 * 60 * 60)),
                    spanH = differTime - h * (1000 * 60 * 60),
                    min = Math.floor(spanH / (1000 * 60)),
                    spanMin = spanH - min * (1000 * 60),
                    sec = Math.floor(spanMin / 1000);
                if(differTime<=0){
                    $ter.css('display','none');
                    $tipEnd.css('display','block');
                    $tipEnd[0].innerHTML='抢购活动已结束！';
                    window.clearTimeout(_this.timer);
                    return;
                }else {
                    if(str===''&&differTime>=0){
                        $endTip.html('距离本场结束:');
                        str += '<span class="terminal_time_limit">' + zero(h) + '</span>';
                        str += '<span>:</span><span class="terminal_time_limit">' + zero(min) + '</span>';
                        str += '<span>:</span><span class="terminal_time_limit">' + zero(sec) + '</span>';
                        $ter.css('display', 'block');
                        $tipEnd.css('display', 'none');
                        $ter[0].innerHTML = str;
                    }
                }
            }
            _this.timer=window.setTimeout(formateTime,1000);
        }
        formateTime();

    }

    //获取商品规格，默认，选取每一个规格的第一个值
    function getRegular(goodsId) {
        $.ajax({
          //  url:'http://192.168.1.100:28080/b2b2c-fx/api/v2/mobile/goods/spec/default.do',
       //    url: 'http://www.yindianmall.com/api/v2/mobile/goods/spec/default.do',
        //   url: 'http://139.224.3.9:10888/b2b2c/api/v2/mobile/goods/spec/default.do',
           url: ""+commom_url+"/api/v2/mobile/goods/spec/default.do",
            dataType: 'jsonp',
            data: {
                id: goodsId
            },
            success: function (data) {
                var str = '';
                str += "<p>已选</p>";
                str += "<p class='standard'>" + data.data.defaultSpec + "</p>";
                str += "<p>&gt</p>";
                $('.hasSelect').html(str)
            }
        });
        defaultEvent();
    }
    //获取商品规格，通过点击页面动态获取
    function getPage(goodsId) {
        $.ajax({
          //  url: 'http://192.168.1.100:28080/b2b2c-fx/api/v2/mobile/goods/spec/app.do',
          //   url: 'http://www.yindianmall.com/api/v2/mobile/goods/spec/app.do',
          //  url: 'http://139.224.3.9:10888/b2b2c/api/v2/mobile/goods/details/get.do',
            url: ""+commom_url+"/api/v2/mobile/goods/details/get.do",
            dataType: 'jsonp',
            data: {
                id: goodsId
            },
            success: function (data) {
               var oCH=document.getElementById('ban');
               var oDesc=document.getElementById('desc');
                var str='';
                var str2='';
                var index=data.data.gallery.length-1;
                for(var i=0;i<data.data.gallery.length;i++){
                    str+='<img class="swiper-slide" src='+data.data.gallery[i].big+'>';
                }
                str+='<img class="swiper-slide" src='+data.data.gallery[index].big+'>';
                $(oCH).html(str);
                str2+='<p class="introduce">'+data.data.goods.name+'</p>';
                str2+='<p class="price">￥<i>'+data.data.goods.price+'</i></p>';
                str2+='<span class="bianhao">编号：'+data.data.goods.sn+'</span>';
              /*  str2+='<p class="stock">库存：</p>';*/
                str2+='<p class="sailCount">销量:'+data.data.goods.buyNum+'</p>';

                $(oDesc).html(str2)
            }
        });
        defaultEvent();
    }


    //根据规格，数量确定规格显示
    function getCount() {
        $.ajax({
           // url:'http://192.168.1.100:28080/b2b2c-fx/api/v2/mobile/goods/spec/confirm.do',
           //  url: 'http://www.yindianmall.com/api/v2/mobile/goods/spec/confirm.do',
          //   url: 'http://139.224.3.9:10888/b2b2c/api/v2/mobile/goods/spec/confirm.do',
             url: ""+commom_url+"/api/v2/mobile/goods/spec/confirm.do",
            dataType: 'jsonp',
            data: {
                param: '1',
                num: '1'
            },
            success: function (data) {
            }
        });
        defaultEvent();
    }

    //获取商品(具体信息)
   /* function getBrand() {
        $.ajax({
            url: 'http://www.yindianmall.com/api/v2/mobile/goods/details/get.do',
            dataType: 'jsonp',
            data: {
                id: 358
            },
            success: function (data) {
                // console.log(data);
                var str = '';
                for (var i = 0; i < data.data.gallery.length; i++) {
                    str += "<img class='swiper-slide' src=" + data.data.gallery[i].big + " />";
                }
                $('.brandImg').html(str);
                $('.introduce').html(data.data.goods.name);
                $('.price').html("<span>¥" + data.data.goods.mktprice + "</span>");
                $('.bianhao').html("编号:" + data.data.goods.sn + "");
            }
        });
    }*/
    //获取商品评价，根据评价等级
    function getComment(obj) {
        var dat={};
        for(var key in obj){
            dat[key]=obj[key]
        }
        $.ajax({
          //  url: 'http://www.yindianmall.com/api/v2/mobile/goods/comment/list.do',
         //   url: 'http://139.224.3.9:10888/b2b2c/api/v2/mobile/goods/comment/list.do',
            url: ""+commom_url+"/api/v2/mobile/goods/comment/list.do",
            data:dat,
            dataType: 'jsonp',
            success: function (data) {
                var $arrList=$('#arrList');
                var $none=$('#none');
                var str='';
                if(data.data.commentList.length===0){
                    $arrList.css('display','none');
                    $none.css('display','block');
                }else {
                    $none.css('display','none');
                    for(var i=0;i<data.data.commentList.length;i++){
                        var cur=data.data.commentList[i];
                        var timeStamp=data.data.commentList[i].dataLine;
                        var unixTimestamp = new Date(timeStamp* 1000);
                        var commonTime = unixTimestamp.toLocaleString();
                        var date=new Date(timeStamp);
                        var curTime=date.getFullYear() + '/' + (date.getMonth() + 1) + '/' + date.getDate();
                        str+='<div class="commentList">';
                        str+='<div class="listHead" goodId="'+cur.goods_id+'" grade="+cur.grade+" >';
                        str+='<i class="idIcon">';
                        str+='<img src="'+cur.face+'" alt="用户名">';
                        str+='</i>';
                        str+='<p class="idName">'+cur.name+'</p>';
                        str+='<p class="data">'+commonTime+'</p>';
                        str+='<div class="listContent">';
                        str+='<ul class="star"><li></li><li></li><li></li><li></li><li></li></ul>';
                        str+='<p>'+cur.content+'</p>';
                        str+='<div class="comList">';
                        if(cur.commentGalleryList.length){
                            for(var j=0;j<cur.commentGalleryList.length;j++){
                                var curP=cur.commentGalleryList[j];
                                str+='<img id="comP" src="'+curP.original+'" imgId="'+curP.img_id+'">';
                            }
                        }
                        str+='</div>';
                        str+='</div>';
                        str+='</div>';
                        str+='</div>';
                    };
                    $arrList.css('display','block');
                }
                $arrList.html(str);
            }
        });
        defaultEvent();

    }
    //商品评价的初步获取，总数，好评率
    function commentRate(goodsId) {
        $.ajax({
          //  url:'http://192.168.1.100:28080/b2b2c-fx/api/v2/mobile/goods/comment/count/list.do',
          //  url: 'http://www.yindianmall.com/api/v2/mobile/goods/comment/count/list.do',
         //   url: 'http://139.224.3.9:10888/b2b2c/api/v2/mobile/goods/comment/count/list.do',
            url: ""+commom_url+"/api/v2/mobile/goods/comment/count/list.do",
            dataType: 'jsonp',
            data: {
                goodsId: goodsId
            },
            success: function (data) {
                var $commentListHead=$('.commentListHead');
                var str='';
                str+='<div class="commentListHead">';
                str+='<p>商品评价('+data.data.commentCount+')</p>';
                str+='<p>'+data.data.goodCommentRate+'</p>';
                str+='<span>好评</span>';
                str+='</div>';
                $commentListHead.eq(0).html(str);
            }
        });
        defaultEvent();
    }

    // //获取商品(详情-基本信息)
    function getBasic(goodsId) {
        $.ajax({

         //   url: 'http://192.168.1.100:28080/b2b2c-fx/api/v2/mobile/goods/details/base/get.do',
         //    url: 'http://www.yindianmall.com/api/v2/mobile/goods/details/base/get.do',
         //    url: 'http://139.224.3.9:10888/b2b2c/api/v2/mobile/goods/details/base/get.do',
             url: ""+commom_url+"/api/v2/mobile/goods/details/base/get.do",
            dataType: 'jsonp',
            data: {
                id: goodsId
            },
            success: function (data) {
            /*     console.log(data);*/
                // var str = data.data,
                //     strContent='';
                //     var reg=/([http]\w+(?::\/\/)[.|\w|/|\d]+)/g;
                //     var listAry=str.match(reg);
                //     for(var i=0;i<listAry.length;i++){
                //         var curImg=listAry[i];
                //         strContent += "<img class='changepic' src=" +curImg+ ">";
                //     }
                $('.pic .one').html(data.data)
            }
        });
        defaultEvent();
    }


    //获取商品(详情-商品属性)
    function getBrandAttr(goodsId) {
        $.ajax({
           // url:'http://192.168.1.100:28080/b2b2c-fx/api/v2/mobile/goods/attr-list.do',
          //  url: 'http://www.yindianmall.com/api/v2/mobile/goods/attr-list.do',
          //  url: 'http://139.224.3.9:10888/b2b2c/api/v2/mobile/goods/attr-list.do',
            url: ""+commom_url+"/api/v2/mobile/goods/attr-list.do",
            dataType: 'jsonp',
            data: {
                goodsid: goodsId
            },
            success: function (data) {
                var str = '';
                for (var i = 0; i < data.data.length; i++) {
                    str += "<p>" + data.data[i].attrName + ":" + data.data[i].attrValue + "</p>";

                }
                $('.pic .two').html(str)
            }
        });
        defaultEvent();
    }
    // 点击下载app
    function downloadApp() {
        //点击下载app
        var u = navigator.userAgent;
        var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
        var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端

        $('.lastIndex').tap(function () {
            if (isiOS) {
                window.location.href='https://itunes.apple.com/us/app/%E9%93%B6%E7%82%B9%E5%95%86%E5%9F%8E/id1205112655?l=zh&ls=1&mt=8';
                alert('请点击右上角，选择在浏览器中打开，再点击商城App下载按钮');
            }else{
                window.location.href='https://www.pgyer.com/YinDianShop';
            }
        });
    }

    //滚动商品区域时，组织默认冒泡事件
    function defaultEvent() {
        var $main=$('.main');
        $document=$(document);
        $main.on('touchmove', function (e) {
            console.log('123456');
            e.stopPropagation(); }, false);
        $document.on('touchmove', function (e) {
            e.preventDefault(); }, false)
    }
    return {
        init: function () {
            defaultEvent();
            //clickDot();
            switchItem();
            //cartFuc();
            brandLis();
         //   comment();
            clickCheckComment();
            /*ajax请求部分*/
            defaultMsg();
            getCount();
            downloadApp();

        }
    }
})();
brand.init();



































